/**
 * 实验部分
 * InfoToTxt实现功能：将ID相同的内容存到相同的Txt中
 */
/**
 * @author zhengtaishuai
 *
 */
package experiment;