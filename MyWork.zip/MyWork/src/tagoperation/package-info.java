/**
 * 对标注的标签进行的操作
 * TagClassifyInstance用于将标注的数据按照标签分别保存到Excel表格之中
 * 路径为："file/标注术语/"+"关键词"
 */
/**
 * @author zhengtaishuai
 *
 */
package tagoperation;