/**
 * 信息抽取
 */
/**
 * @author zhengtaishuai
 *
 */
package informationextraction;