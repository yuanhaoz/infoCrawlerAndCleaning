package mysql;

public class MysqlTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MysqlOperationExample mysqlopera = new MysqlOperationExample();
		mysqlopera.insert();
//		mysqlopera.select();
//		mysqlopera.update();
//		mysqlopera.delete();
	}

}
