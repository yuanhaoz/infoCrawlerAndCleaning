/**
 * 
 */
/**
 * @author weibifan
 * 目的：将web page当做文件来处理。
 * 基本功能：下载，url操作，格式转换，搜索，替换
 */
package webpage;